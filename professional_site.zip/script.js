
function validateLogin(event) {
    event.preventDefault();
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var errorMsg = document.getElementById("errorMsg");

    if(username === "admin" && password === "1234") {
        window.location.href = "index.html";
    } else {
        errorMsg.textContent = "Nom d’utilisateur ou mot de passe incorrect";
    }
}
